# RevaBrain — Ralph loop (Claude Code)

![Ralph](ralph.webp)

Deze repository is een **Claude Code**-gebaseerde Ralph loop setup voor het project **RevaBrain** (zie `prd.md`).

Ralph is een autonome agent loop die Claude Code herhaaldelijk aanroept tot alle user stories in `prd.json` op `passes=true` staan. Iedere iteratie is “fresh context”; geheugen blijft bestaan via git history, `progress.txt` en `prd.json`.

## Belangrijkste bestanden

| Bestand | Doel |
|--------|------|
| `prd.md` | Volledige Product Requirements Document (bron van requirements) |
| `prd.json` | Ralph backlog: user stories met `passes` status |
| `claude.md` | Prompt die elke iteratie aan Claude Code wordt gevoerd |
| `agent.md` | Engineering regels: DRY, dependency-hygiëne, GDPR/security, Definition of Done |
| `progress.txt` | Append-only learnings & context tussen iteraties |
| `.claude/CLAUDE.md` | Claude Code project memory (importeert o.a. `agent.md`) |
| `ralph.sh` | De loop die iteraties uitvoert en stories afvinkt |
| `skills/` | (Optioneel) skills om PRD → JSON om te zetten en workflows te sturen |

## Prerequisites

- **Claude Code** geïnstalleerd en geauthenticeerd
- `jq` geïnstalleerd (macOS: `brew install jq`)
- Git repo (je werkt per feature op een branch)

> Tip: Claude Code heeft meerdere installatiemethodes (native install, Homebrew, WinGet, …). Zie de officiële Claude Code “Setup”/“Quickstart” docs voor de aanbevolen installatie.

## Setup

### 1) Claude Code project memory (DRY)

Deze repo gebruikt `.claude/CLAUDE.md` als Claude Code project memory. Dit bestand importeert `agent.md`, zodat regels maar op één plek onderhouden worden.

### 2) (Optioneel) skills installeren

Als je de meegeleverde skills wil gebruiken (PRD → `prd.json` conversie), installeer ze globaal:

```bash
cp -r skills/prd ~/.claude/skills/
cp -r skills/ralph ~/.claude/skills/
```

## Workflow

### 1) PRD bijwerken

- Pas requirements aan in `prd.md`.

### 2) Backlog bijwerken

- Houd `prd.json` in sync met de gewenste user stories (incl. priorities).
- Elke story heeft een `passes` status die door Ralph wordt aangepast.

### 3) Run Ralph

```bash
./ralph.sh 10
```

Ralph zal per iteratie:
1. De hoogste prioriteit story kiezen met `passes=false`
2. Claude Code laten implementeren (via `claude.md`)
3. `prd.json` updaten (`passes=true`)
4. `progress.txt` uitbreiden
5. Committen op de branch uit `prd.json.branchName`

Stopconditie: als alles af is, output Ralph `<promise>COMPLETE</promise>`.

## Dependency auto-update

- Dependabot is geconfigureerd via `.github/dependabot.yml` om dependencies (o.a. in `flowchart/`) en GitHub Actions up-to-date te houden.
- Zie `agent.md` voor het policy kader (hygiene, grouping, CI gates).

## Flowchart

[![Ralph Flowchart](ralph-flowchart.png)](https://snarktank.github.io/ralph/)

De `flowchart/` directory bevat een kleine React-app om de loop te visualiseren:

```bash
cd flowchart
npm install
npm run dev
```
