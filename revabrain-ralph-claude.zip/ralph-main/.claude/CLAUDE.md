# Claude Code project memory — RevaBrain

Deze repo gebruikt Claude Code + Ralph loop.

## Belangrijkste documenten

- Werkafspraken / engineering regels: `agent.md`
- Product requirements: `prd.md`
- Ralph backlogstatus: `prd.json`
- Iteratie-logboek: `progress.txt`

## Instructies (ingeladen)

@../agent.md

## Praktisch

- Ralph loop starten: `./ralph.sh`
- Let op privacy: behandel RR en andere persoonsgegevens als **PII**; log of commit ze niet in plaintext.
